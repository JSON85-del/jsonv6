# JARVIS AR

Production-oriented iPhone AR assistant inspired by Iron Man / JARVIS interfaces.

This is a **real iOS application architecture** using ARKit, RealityKit, Vision, Speech, and a secure Grok proxy. It is **not** a video mockup.

## What this is — and is not

**This project is:**
- Native Swift / SwiftUI / RealityKit source you can build in Xcode on a Mac
- Wired to real Apple APIs for camera, world tracking, plane detection, Vision hand pose, OCR, speech, and haptics
- Designed so Grok is the reasoning engine behind a named assistant called JARVIS
- Honest about hardware: no fake holograms in empty air, no wall-penetration, no invented inventory numbers

**This project is not:**
- A compiled `.ipa` produced on this Linux environment (Xcode and iOS SDKs are Apple-only)
- A claim that an iPhone can do Vision Pro full 3D skeletal hand tracking
- A movie-asset clone (original HUD; cyan/glass language only)

Hand interaction on iPhone uses **Vision `VNDetectHumanHandPoseRequest`** (2D joints from the camera) plus **ARKit unprojection / raycasts** into the world. That is the supported path on iPhone. Full 3D `HandTrackingProvider` exists on visionOS / Apple Vision Pro; the architecture is isolated so that platform can be added later.

## Requirements

| Item | Requirement |
| --- | --- |
| Mac | macOS with Xcode 16+ |
| Device | iPhone with A12+ recommended; LiDAR Pro models get better planes / mesh |
| iOS | 17.0+ (18+ preferred) |
| Accounts | Apple Developer (device deploy), xAI API key (server only) |
| Tools | XcodeGen (`brew install xcodegen`) optional but recommended |

The iOS Simulator **cannot** run ARKit world tracking. Use a physical iPhone.

## Repository layout

```
JARVIS-AR/
  README.md
  Docs/
  backend/                 Secure Grok + product proxy (FastAPI)
  iOS/JARVISAR/            Native app source
  scripts/
```

## Quick start — iOS

```bash
cd iOS
brew install xcodegen        # once
xcodegen generate
open JARVISAR.xcodeproj
```

1. Select your Development Team in Signing & Capabilities.
2. Set the backend base URL in `Resources/Config.plist` (or Xcode scheme env).
3. Plug in an iPhone, enable Developer Mode, Run.

Without XcodeGen, create a new iOS App target named `JARVISAR` (SwiftUI, iOS 17) and add every file under `iOS/JARVISAR/`.

## Quick start — backend

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export XAI_API_KEY="xai-..."          # never put this in the iOS app
export JARVIS_API_TOKEN="dev-token"   # shared secret the app sends
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

Point the iPhone at that host (Mac LAN IP on the same Wi-Fi, or a deployed HTTPS URL).

## Architecture

```
Camera (ARKit) ──► Vision (hands, classify, OCR)
       │                    │
       ▼                    ▼
 RealityKit world     GestureManager
       │                    │
       ▼                    ▼
  Spatial anchors     CommandManager ◄── GrokManager ──HTTPS──► backend ──► api.x.ai
       │
       ▼
   HUD overlay (SwiftUI, transparent)
       │
 VoiceManager (Speech + AVSpeechSynthesizer)
```

Managers are independently testable and do not import SwiftUI except HUD / Settings views.

### Modules

| Module | Responsibility |
| --- | --- |
| `ARManager` | World tracking, planes, raycasts, RealityKit scene |
| `VisionManager` | Frame throttle, classification, OCR |
| `HandTrackingManager` | 2-hand pose from Vision |
| `GestureManager` | Pinch, point, grab, scale, rotate, palm, swipe |
| `VoiceManager` | Recognition + TTS |
| `GrokManager` | Structured context → backend |
| `CommandManager` | Allowlisted actions only |
| `SpatialManager` | Session-scoped anchors |
| `HUDManager` | Status + holographic chrome |
| `ObjectRecognitionManager` | Labels + confidence |
| `ProductManager` | Product DB abstraction |
| `MHMManager` | Future MHM inventory adapter |
| `SettingsManager` | Preferences + privacy |
| `SecurityManager` | Token handling, command validation |

## Grok integration

The iPhone **never** embeds `XAI_API_KEY`.

It posts a structured payload to `/v1/jarvis/turn`:

```json
{
  "user_query": "What is this?",
  "detected_object": "mattress",
  "ocr_text": ["Dodoma Asili"],
  "context": "AR_CAMERA",
  "mode": "scan",
  "available_actions": ["SCAN_OBJECT", "SHOW_INFORMATION", "SEARCH"],
  "conversation_id": "..."
}
```

The backend calls `https://api.x.ai/v1/chat/completions` and asks Grok to return **either** conversational text **or** a validated command object. Unknown intents are dropped.

## Permissions (real reasons shown in-app)

- **Camera** — live AR view, hand pose, object/text recognition
- **Microphone** — voice commands
- **Speech Recognition** — on-device / Apple speech
- **Location (when in use)** — optional navigation / geotagged session notes
- **Motion** — ARKit world tracking

Camera frames are processed on-device. Only compact structured context (query, labels, OCR strings, mode) is sent to the backend when the user invokes JARVIS.

## Modes

`default`, `scan`, `hud`, `handControl`, `product`, `navigation`, `mhm`, `system`

MHM / product inventory numbers are **never hardcoded**. Sample catalog rows are flagged `isSampleData = true`. Live stock requires a configured MHM backend.

## Fallback behavior

| Failure | UI | Still works |
| --- | --- | --- |
| Hand tracking lost | `HAND TRACKING UNAVAILABLE` | Touch + voice |
| Grok / network down | `AI CONNECTION UNAVAILABLE` | AR, hands, local Vision |
| AR tracking limited | Tracking hint | Camera + HUD + voice |
| Permission denied | Settings deep-link | Everything else that remains legal |

Status chips show **measured** subsystem state, never a painted “ONLINE” for a service that failed to start.

## Performance

- Vision hand pose ~15 Hz, classification / OCR on demand or ~2 Hz in Scan mode
- RealityKit rendering targeted at 60 FPS on supported devices
- No full-frame cloud video upload

## Legal / IP

Original HUD. No copied Marvel / Disney assets, fonts, or trademarked helmet graphics. “JARVIS” here is an in-app assistant name.

## Phased implementation map

The source is organized so you can enable features in the order specified in the product brief:

1. AR camera (`ARManager`, `ARCameraView`)
2. HUD (`HUDOverlayView`)
3. Hand tracking
4. Gestures
5. 3D object interaction
6. Voice
7. Grok
8. Object recognition
9. OCR
10. Spatial memory (session)
11. Product / MHM adapters
12. Hardening

See `Docs/ARCHITECTURE.md` and `Docs/CAPABILITIES.md`.


## Vercel deployment

This repository is Vercel-ready for the FastAPI backend. Vercel hosts the backend; the native iOS app continues to run in Xcode on a physical iPhone.

### 1. Import the repository into Vercel

Set the Vercel project root to the repository root (`JARVIS-AR`). Vercel will detect `app.py` as the FastAPI entrypoint.

### 2. Add environment variables

Set these in Vercel Project Settings → Environment Variables:

- `XAI_API_KEY` — your xAI API key. **Never put this in the iOS app.**
- `JARVIS_API_TOKEN` — a long random bearer token shared with the app.
- `GROK_MODEL` — `grok-4.7`
- `GROK_REASONING_EFFORT` — `low` for fast AR responses (use `medium`/`high` if latency is acceptable).
- `XAI_BASE_URL` — `https://api.x.ai/v1`

### 3. Deploy

After deployment, verify:

```text
https://YOUR-PROJECT.vercel.app/v1/health
```

It should return JSON containing `ok: true` and the configured model.

### 4. Connect the iPhone

Edit `iOS/JARVISAR/Resources/Config.plist`:

- `BackendBaseURL` → your Vercel HTTPS URL
- `AppAPIToken` → the same `JARVIS_API_TOKEN`

Then regenerate/open the Xcode project and build to a physical iPhone.

### Important security note

`JARVIS_API_TOKEN` is embedded in the iOS application and therefore should be treated as a client credential, not a true secret. For a public production app, replace the shared token with per-device/user authentication and a persistent rate limiter/database. The xAI key must remain server-side only.


### Root URL fixed

The FastAPI application now exposes `/`, so the Vercel project URL is no longer a 404. It returns JARVIS service status and links to `/docs` and `/v1/health`.
