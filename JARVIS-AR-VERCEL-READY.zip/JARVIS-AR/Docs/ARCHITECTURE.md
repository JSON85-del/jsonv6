# Architecture

## Data flow

1. `ARManager` owns `ARView` and the `ARSession`.
2. Each `ARFrame` is offered to `VisionManager` with a budget (skip frames).
3. `HandTrackingManager` converts Vision joints to `TrackedHand` (screen + optional world ray).
4. `GestureManager` publishes `GestureEvent`s.
5. `InteractionController` maps gestures onto RealityKit entities and HUD hit-tests.
6. `VoiceManager` emits transcripts. Wake-filter requires an explicit “JARVIS” prefix unless the mic button is held.
7. `GrokManager` builds `JarvisTurnRequest` and calls the proxy.
8. `CommandManager` accepts only `JarvisCommand.Intent` raw values from an allowlist.

## Command schema

```json
{
  "intent": "MOVE_AR_OBJECT",
  "target": "selected_panel",
  "direction": "toward_user",
  "magnitude": 0.2
}
```

If Grok returns prose plus a command, the command is executed only after schema validation. No shell, no URL load of arbitrary schemes, no Settings writes outside the declared set.

## Replaceable AI

`AIReasoningService` is a protocol. `GrokBackendService` is the production implementation. `OfflineReasoningService` returns a local fallback sentence when the proxy is down.

## Threading

- ARSession callbacks: session queue
- Vision: dedicated `DispatchQueue(label: "jarvis.vision", qos: .userInitiated)`
- RealityKit mutations: main
- Network: async/await

## Security

- App talks only to `backendBaseURL`
- `Authorization: Bearer <app token>` (rotatable; not the xAI key)
- Backend holds `XAI_API_KEY`
- Rate limit per token
- Prompt injection defense: actions parsed as JSON, not executed from free text
