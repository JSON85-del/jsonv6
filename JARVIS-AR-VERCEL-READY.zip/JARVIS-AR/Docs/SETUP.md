# Setup on a Mac

## 1. Xcode project

```bash
cd iOS
brew install xcodegen
xcodegen generate
open JARVISAR.xcodeproj
```

Signing: pick your team. Bundle ID `com.mhm.jarvisar` can be changed.

If XcodeGen is unavailable, File → New → Project → iOS App, then drag the `JARVISAR` folder in.

## 2. Device

- Settings → Privacy & Security → Developer Mode → On
- Trust the computer
- Build to the iPhone (not Simulator)

## 3. Backend

On your Mac (same Wi-Fi as the phone):

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export XAI_API_KEY=xai-your-key
export JARVIS_API_TOKEN=dev-token
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

Edit `iOS/JARVISAR/Resources/Config.plist`:

- `BackendBaseURL` → `http://YOUR_MAC_LAN_IP:8080`
- ATS: HTTP on a local network requires an App Transport exception, or use HTTPS.

Add to Info.plist if using LAN HTTP:

```xml
<key>NSAppTransportSecurity</key>
<dict>
  <key>NSAllowsLocalNetworking</key>
  <true/>
</dict>
```

## 4. xAI key

Create a key at https://console.x.ai — server environment only.

## 5. MHM

Leave `MHMBaseURL` empty until the inventory API exists. The adapter will report `not configured` instead of inventing stock.


## Vercel backend

The repository root now contains `app.py`, `requirements.txt`, and `vercel.json` for Vercel's FastAPI runtime. Deploy the repository root to Vercel and configure the environment variables listed in `README.md`.
