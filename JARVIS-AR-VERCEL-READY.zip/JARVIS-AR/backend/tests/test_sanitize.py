from app.main import ALLOWED_INTENTS, heuristic_command, sanitize_command


def test_drops_unknown_intent():
    assert sanitize_command({"intent": "FORMAT_DISK"}) is None


def test_allows_scan():
    cmd = sanitize_command({"intent": "SCAN_OBJECT"})
    assert cmd is not None
    assert cmd.intent in ALLOWED_INTENTS


def test_heuristic_scan():
    cmd = heuristic_command("JARVIS, scan this")
    assert cmd is not None
    assert cmd.intent == "SCAN_OBJECT"
