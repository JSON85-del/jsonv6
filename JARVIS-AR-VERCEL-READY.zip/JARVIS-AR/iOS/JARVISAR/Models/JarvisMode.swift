import Foundation

enum JarvisMode: String, CaseIterable, Identifiable {
    case defaultMode = "default"
    case scan
    case hud
    case handControl
    case product
    case navigation
    case mhm
    case system

    var id: String { rawValue }

    var title: String {
        switch self {
        case .defaultMode: return "DEFAULT"
        case .scan: return "SCAN"
        case .hud: return "HUD"
        case .handControl: return "HAND"
        case .product: return "PRODUCT"
        case .navigation: return "NAV"
        case .mhm: return "MHM"
        case .system: return "SYSTEM"
        }
    }
}
