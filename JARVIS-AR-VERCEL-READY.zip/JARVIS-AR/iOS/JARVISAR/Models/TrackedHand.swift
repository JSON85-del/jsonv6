import Foundation
import CoreGraphics
import simd
import Vision

enum HandChirality: String {
    case left
    case right
    case unknown
}

struct HandJoint: Equatable {
    var name: String
    var screenPoint: CGPoint
    var confidence: Float
}

struct TrackedHand: Identifiable, Equatable {
    var id: String
    var chirality: HandChirality
    var joints: [String: HandJoint]
    var palm: CGPoint?
    var wrist: CGPoint?
    var indexTip: CGPoint?
    var thumbTip: CGPoint?
    var worldRayOrigin: SIMD3<Float>?
    var worldRayDirection: SIMD3<Float>?
    var isLost: Bool = false

    var pinchDistance: CGFloat {
        guard let a = thumbTip, let b = indexTip else { return .greatestFiniteMagnitude }
        let dx = a.x - b.x
        let dy = a.y - b.y
        return sqrt(dx * dx + dy * dy)
    }
}

enum GestureKind: String {
    case pinch
    case release
    case point
    case grab
    case move
    case twoHandScale
    case twoHandRotate
    case openPalm
    case swipe
    case doublePinch
}

struct GestureEvent: Equatable {
    var kind: GestureKind
    var handID: String? = nil
    var screenPoint: CGPoint? = nil
    var delta: CGSize? = nil
    var scale: CGFloat? = nil
    var rotation: CGFloat? = nil
    var swipeDirection: String? = nil
}
