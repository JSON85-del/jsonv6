import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var app: AppState
    @ObservedObject private var settings = SettingsManager.shared

    var body: some View {
        NavigationStack {
            List {
                Section("AI") {
                    Toggle("Share AR context with Grok", isOn: $settings.shareAIContext)
                    LabeledContent("Backend") { Text(settings.backendBaseURL).font(.caption2) }
                    LabeledContent("Model") { Text(settings.grokModel).font(.caption) }
                }
                Section("AR") {
                    Slider(value: $settings.hudIntensity, in: 0.2...1) { Text("HUD intensity") }
                    Slider(value: $settings.animationIntensity, in: 0...1) { Text("Animation") }
                }
                Section("Hand tracking") {
                    Slider(value: Binding(get: { settings.pinchThreshold }, set: { settings.pinchThreshold = $0 }), in: 16...48)
                    { Text("Pinch threshold") }
                    Stepper("Evidence frames \(settings.gestureEvidenceFrames)", value: $settings.gestureEvidenceFrames, in: 1...8)
                }
                Section("Voice") {
                    Toggle("Accept speech after mic tap without saying JARVIS", isOn: $settings.alwaysListenAfterTap)
                }
                Section("Privacy") {
                    Toggle("Analytics", isOn: $settings.analyticsEnabled)
                    Toggle("Location for nav notes", isOn: $settings.locationEnabled)
                    Text("Camera frames are processed on-device. Only compact labels, OCR strings, and your question are sent to the backend when you talk to JARVIS.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                Section("MHM") {
                    Toggle("Enable MHM mode", isOn: $settings.mhmModeEnabled)
                    LabeledContent("MHM URL") { Text(settings.mhmBaseURL.isEmpty ? "not configured" : settings.mhmBaseURL).font(.caption2) }
                }
                Section("Sound & haptics") {
                    Toggle("Sound effects", isOn: $settings.soundEnabled)
                    Toggle("Haptics", isOn: $settings.hapticsEnabled)
                    Toggle("High contrast", isOn: $settings.highContrast)
                    Toggle("Reduced motion", isOn: $settings.reducedMotion)
                }
            }
            .navigationTitle("System")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { app.showSettings = false }
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}
