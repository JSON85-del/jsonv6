import Foundation
import Combine

enum AIVisualState {
    case idle
    case listening
    case processing
    case speaking
}

@MainActor
final class HUDManager: ObservableObject {
    @Published var bootLines: [BootLine] = []
    @Published var cameraStatus = "…"
    @Published var arStatus = "…"
    @Published var visionStatus = "…"
    @Published var handStatus = "…"
    @Published var voiceStatus = "…"
    @Published var grokStatus: ServiceStatus = .unknown
    @Published var modeLabel = "DEFAULT"
    @Published var aiState: AIVisualState = .idle
    @Published var radialOpen = false
    @Published var infoPanel: InfoPanelModel?
    @Published var cursor: CGPoint?
    @Published var hoverLabel: String?
    @Published var trackingBanner: String?

    func resetBootLog() {
        bootLines = []
    }

    func mark(_ name: String, success: Bool) async {
        let line = BootLine(name: name, ok: success)
        bootLines.append(line)
        switch name {
        case "CAMERA": cameraStatus = success ? "ONLINE" : "OFFLINE"
        case "AR ENGINE": arStatus = success ? "TRACKING" : "OFFLINE"
        case "VISION": visionStatus = success ? "ACTIVE" : "OFFLINE"
        case "HAND TRACKING": handStatus = success ? "ACTIVE" : "UNAVAILABLE"
        case "VOICE": voiceStatus = success ? "ONLINE" : "OFFLINE"
        case "GROK": grokStatus = success ? .connected : .offline
        default: break
        }
        try? await Task.sleep(nanoseconds: 180_000_000)
    }

    func showInfoFrom(objects: ObjectRecognitionManager, products: ProductManager) {
        infoPanel = InfoPanelModel(
            title: objects.primaryLabel?.capitalized ?? "Unknown object",
            subtitle: objects.confidenceText,
            body: objects.detailLines + products.matchingLines(for: objects.primaryLabel),
            uncertain: objects.isUncertain
        )
    }

    func dismissInfo() {
        infoPanel = nil
    }
}

struct BootLine: Identifiable {
    let id = UUID()
    let name: String
    let ok: Bool
}

struct InfoPanelModel: Identifiable, Equatable {
    var id = UUID()
    var title: String
    var subtitle: String
    var body: [String]
    var uncertain: Bool
}
