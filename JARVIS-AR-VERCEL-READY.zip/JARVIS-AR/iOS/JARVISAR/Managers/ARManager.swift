import Foundation
import ARKit
import RealityKit
import Combine
import UIKit

@MainActor
final class ARManager: NSObject, ObservableObject {
    @Published var isRunning = false
    @Published var trackingState: ARCamera.TrackingState = .notAvailable
    @Published var trackingHint: String?
    @Published var viewBounds: CGSize = .init(width: 390, height: 844)
    @Published var planeCount = 0
    @Published var lidarAvailable = false

    let framePublisher = PassthroughSubject<ARFrame, Never>()
    private(set) var latestFrame: ARFrame?
    private(set) var arView: ARView?
    private var session: ARSession { arView?.session ?? ARSession() }

    func attach(_ view: ARView) {
        arView = view
        view.session.delegate = self
        view.renderCallbacks.postProcess = nil
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            view.environment.sceneUnderstanding.options.insert(.occlusion)
            view.environment.sceneUnderstanding.options.insert(.collision)
        }
        viewBounds = view.bounds.size
    }

    func requestCamera() async -> Bool {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        switch status {
        case .authorized: return true
        case .notDetermined:
            return await withCheckedContinuation { cont in
                AVCaptureDevice.requestAccess(for: .video) { ok in
                    cont.resume(returning: ok)
                }
            }
        default:
            trackingHint = "Camera permission denied"
            return false
        }
    }

    func start() async -> Bool {
        guard ARWorldTrackingConfiguration.isSupported else {
            trackingHint = "AR world tracking is not supported on this device"
            isRunning = false
            return false
        }
        guard let arView else {
            trackingHint = "AR view not attached"
            return false
        }
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal, .vertical]
        config.environmentTexturing = .automatic
        if ARWorldTrackingConfiguration.supportsFrameSemantics(.sceneDepth) {
            config.frameSemantics.insert(.sceneDepth)
        }
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) {
            config.sceneReconstruction = .mesh
            lidarAvailable = true
        } else {
            lidarAvailable = false
        }
        arView.session.run(config, options: [.resetTracking, .removeExistingAnchors])
        isRunning = true
        trackingHint = nil
        return true
    }

    func pause() {
        arView?.session.pause()
        isRunning = false
    }

    func raycast(from screen: CGPoint) -> SIMD3<Float>? {
        guard let arView else { return nil }
        let results = arView.raycast(from: screen, allowing: .estimatedPlane, alignment: .any)
        if let first = results.first {
            return first.worldTransform.translation
        }
        let existing = arView.raycast(from: screen, allowing: .existingPlaneGeometry, alignment: .any)
        return existing.first?.worldTransform.translation
    }

    func unproject(screen: CGPoint, depth: Float = 0.6) -> (origin: SIMD3<Float>, direction: SIMD3<Float>)? {
        guard let arView, let frame = latestFrame else { return nil }
        let cam = frame.camera
        let viewSize = arView.bounds.size
        let ndcX = Float((screen.x / viewSize.width) * 2 - 1)
        let ndcY = Float(1 - (screen.y / viewSize.height) * 2)
        let clipFar = simd_float4(ndcX, ndcY, 1, 1)
        let inv = simd_inverse(cam.projectionMatrix)
        var viewSpace = inv * clipFar
        viewSpace /= viewSpace.w
        let world = cam.transform * viewSpace
        let origin = cam.transform.translation
        let target = SIMD3<Float>(world.x, world.y, world.z)
        let dir = simd_normalize(target - origin)
        return (origin, dir)
    }

    func addEntity(_ entity: Entity, at world: SIMD3<Float>) {
        guard let arView else { return }
        let anchor = AnchorEntity(world: world)
        anchor.addChild(entity)
        arView.scene.addAnchor(anchor)
    }

    func hitTestEntities(screen: CGPoint) -> Entity? {
        guard let arView else { return nil }
        let hits = arView.hitTest(screen, query: .nearest, mask: .all)
        return hits.first?.entity
    }
}

extension ARManager: ARSessionDelegate {
    nonisolated func session(_ session: ARSession, didUpdate frame: ARFrame) {
        Task { @MainActor in
            self.latestFrame = frame
            self.trackingState = frame.camera.trackingState
            switch frame.camera.trackingState {
            case .normal:
                self.trackingHint = nil
            case .limited(let reason):
                self.trackingHint = Self.describe(reason)
            case .notAvailable:
                self.trackingHint = "AR tracking unavailable"
            }
            self.framePublisher.send(frame)
        }
    }

    nonisolated func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
        Task { @MainActor in
            self.planeCount += anchors.compactMap { $0 as? ARPlaneAnchor }.count
        }
    }

    nonisolated func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        Task { @MainActor in
            self.trackingState = camera.trackingState
        }
    }

    private static func describe(_ reason: ARCamera.TrackingState.Reason) -> String {
        switch reason {
        case .initializing: return "AR initializing…"
        case .excessiveMotion: return "Move more slowly"
        case .insufficientFeatures: return "Point at a textured surface"
        case .relocalizing: return "Relocalizing…"
        @unknown default: return "Tracking limited"
        }
    }
}

extension simd_float4x4 {
    var translation: SIMD3<Float> {
        SIMD3(columns.3.x, columns.3.y, columns.3.z)
    }
}

import AVFoundation
