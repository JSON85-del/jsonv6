import Foundation
import Speech
import AVFoundation
import Combine

@MainActor
final class VoiceManager: NSObject, ObservableObject {
    let transcriptPublisher = PassthroughSubject<String, Never>()
    @Published var micAuthorized = false
    @Published var speechAuthorized = false
    @Published var isListening = false
    @Published var level: Float = 0
    @Published var status = "IDLE"

    private let speech = AVSpeechSynthesizer()
    private var recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private let engine = AVAudioEngine()

    override init() {
        super.init()
        speech.delegate = self
    }

    func prepare() async -> Bool {
        micAuthorized = await requestMic()
        speechAuthorized = await requestSpeech()
        configureSession()
        return micAuthorized && speechAuthorized && (recognizer?.isAvailable ?? false)
    }

    func toggleListen() {
        if isListening { stopListening() } else { startListening() }
    }

    func startListening() {
        guard micAuthorized, speechAuthorized, let recognizer, recognizer.isAvailable else {
            status = "UNAVAILABLE"
            return
        }
        stopListening()
        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        req.requiresOnDeviceRecognition = false
        request = req
        let input = engine.inputNode
        let format = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            self?.request?.append(buffer)
            self?.measure(buffer)
        }
        engine.prepare()
        do {
            try engine.start()
        } catch {
            status = "UNAVAILABLE"
            return
        }
        task = recognizer.recognitionTask(with: req) { [weak self] result, error in
            guard let self else { return }
            if let result, result.isFinal {
                let text = result.bestTranscription.formattedString
                Task { @MainActor in
                    self.transcriptPublisher.send(text)
                    self.stopListening()
                }
            }
            if error != nil {
                Task { @MainActor in self.stopListening() }
            }
        }
        isListening = true
        status = "LISTENING"
    }

    func stopListening() {
        engine.stop()
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        task = nil
        request = nil
        isListening = false
        if status == "LISTENING" { status = "IDLE" }
    }

    func speak(_ text: String) {
        status = "SPEAKING"
        speech.stopSpeaking(at: .immediate)
        let u = AVSpeechUtterance(string: text)
        u.voice = AVSpeechSynthesisVoice(language: "en-US")
        u.rate = AVSpeechUtteranceDefaultSpeechRate * 0.96
        u.pitchMultiplier = 0.95
        speech.speak(u)
    }

    func interruptSpeech() {
        speech.stopSpeaking(at: .immediate)
        if status == "SPEAKING" { status = "IDLE" }
    }

    /// iOS has no supported always-on wake word API. After a tap-to-talk session,
    /// accept utterances that start with JARVIS, or any utterance if `alwaysListenAfterTap`.
    func applyWakeFilter(_ raw: String, alwaysListenAfterTap: Bool) -> String? {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        let lower = trimmed.lowercased()
        if lower.hasPrefix("jarvis") {
            let rest = trimmed.drop { !$0.isWhitespace && $0 != "," }
            let cleaned = rest.trimmingCharacters(in: CharacterSet(charactersIn: ", ").union(.whitespaces))
            return cleaned.isEmpty ? trimmed : cleaned
        }
        return alwaysListenAfterTap ? trimmed : nil
    }

    private func measure(_ buffer: AVAudioPCMBuffer) {
        guard let data = buffer.floatChannelData?[0] else { return }
        let n = Int(buffer.frameLength)
        var sum: Float = 0
        for i in 0..<n { sum += abs(data[i]) }
        let avg = n > 0 ? sum / Float(n) : 0
        Task { @MainActor in self.level = min(1, avg * 8) }
    }

    private func configureSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playAndRecord, mode: .spokenAudio, options: [.defaultToSpeaker, .allowBluetoothHFP])
        try? session.setActive(true)
    }

    private func requestMic() async -> Bool {
        await withCheckedContinuation { cont in
            AVAudioSession.sharedInstance().requestRecordPermission { ok in
                cont.resume(returning: ok)
            }
        }
    }

    private func requestSpeech() async -> Bool {
        await withCheckedContinuation { cont in
            SFSpeechRecognizer.requestAuthorization { status in
                cont.resume(returning: status == .authorized)
            }
        }
    }
}

extension VoiceManager: AVSpeechSynthesizerDelegate {
    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        Task { @MainActor in
            if self.status == "SPEAKING" { self.status = "IDLE" }
        }
    }
}
