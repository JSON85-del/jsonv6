import Foundation

final class SecurityManager {
    private let allowed = Set(JarvisCommand.Intent.allCases.map(\.rawValue))

    func allows(_ command: JarvisCommand) -> Bool {
        allowed.contains(command.intent.rawValue)
    }
}
