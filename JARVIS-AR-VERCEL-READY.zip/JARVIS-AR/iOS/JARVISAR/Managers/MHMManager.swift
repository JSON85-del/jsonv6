import Foundation

/// Abstraction for a future MHM Enterprise inventory backend.
/// Never invents stock counts.
protocol InventoryServicing {
    func lookup(query: String) async throws -> [InventoryRow]
}

struct InventoryRow: Codable {
    var sku: String
    var name: String
    var company: String?
    var type: String?
    var size: String?
    var stock: Int?
    var source: String
}

final class UnconfiguredInventoryService: InventoryServicing {
    func lookup(query: String) async throws -> [InventoryRow] {
        throw MHMError.notConfigured
    }
}

final class HTTPInventoryService: InventoryServicing {
    var baseURL: String
    var token: String
    init(baseURL: String, token: String) {
        self.baseURL = baseURL
        self.token = token
    }
    func lookup(query: String) async throws -> [InventoryRow] {
        guard let url = URL(string: baseURL + "/v1/inventory?q=\(query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query)") else {
            throw MHMError.notConfigured
        }
        var req = URLRequest(url: url)
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        let (data, response) = try await URLSession.shared.data(for: req)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw MHMError.unavailable }
        return try JSONDecoder().decode([InventoryRow].self, from: data)
    }
}

enum MHMError: Error {
    case notConfigured
    case unavailable
}

@MainActor
final class MHMManager: ObservableObject {
    @Published var lastRows: [InventoryRow] = []
    @Published var message: String = "MHM backend not configured"
    private var service: InventoryServicing = UnconfiguredInventoryService()

    func configure(settings: SettingsManager) {
        if !settings.mhmBaseURL.isEmpty {
            service = HTTPInventoryService(baseURL: settings.mhmBaseURL, token: settings.appAPIToken)
            message = "MHM adapter ready"
        } else {
            service = UnconfiguredInventoryService()
            message = "MHM backend not configured"
        }
    }

    func scan(query: String) async {
        do {
            lastRows = try await service.lookup(query: query)
            message = lastRows.isEmpty ? "No MHM match" : "MHM PRODUCT"
        } catch MHMError.notConfigured {
            lastRows = []
            message = "MHM backend not configured"
        } catch {
            lastRows = []
            message = "MHM lookup unavailable"
        }
    }
}
