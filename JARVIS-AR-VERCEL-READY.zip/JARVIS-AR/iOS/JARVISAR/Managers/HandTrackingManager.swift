import Foundation
import Vision
import ARKit
import CoreGraphics
import Combine

@MainActor
final class HandTrackingManager: ObservableObject {
    @Published var hands: [TrackedHand] = []
    @Published var available = true
    @Published var statusText = "ACTIVE"

    private var missingFrames = 0
    private let lostAfter = 12

    func prepare() -> Bool {
        available = true
        statusText = "ACTIVE"
        return true
    }

    func update(observations: [VNHumanHandPoseObservation], viewSize: CGSize, frame: ARFrame?) {
        if observations.isEmpty {
            missingFrames += 1
            if missingFrames > lostAfter {
                hands = hands.map {
                    var h = $0
                    h.isLost = true
                    return h
                }
                if !hands.isEmpty { statusText = "UNAVAILABLE" }
            }
            return
        }
        missingFrames = 0
        statusText = "ACTIVE"
        hands = observations.enumerated().compactMap { index, obs in
            makeHand(obs, index: index, viewSize: viewSize)
        }
    }

    private func makeHand(_ obs: VNHumanHandPoseObservation, index: Int, viewSize: CGSize) -> TrackedHand? {
        guard let points = try? obs.recognizedPoints(.all) else { return nil }
        var joints: [String: HandJoint] = [:]
        for (name, point) in points where point.confidence > 0.25 {
            let key = String(describing: name)
            let screen = CGPoint(
                x: point.location.x * viewSize.width,
                y: (1 - point.location.y) * viewSize.height
            )
            joints[key] = HandJoint(name: key, screenPoint: screen, confidence: point.confidence)
        }

        func pt(_ name: VNHumanHandPoseObservation.JointName) -> CGPoint? {
            guard let p = try? obs.recognizedPoint(name), p.confidence > 0.3 else { return nil }
            return CGPoint(x: p.location.x * viewSize.width, y: (1 - p.location.y) * viewSize.height)
        }

        let chirality: HandChirality
        switch obs.chirality {
        case .left: chirality = .left
        case .right: chirality = .right
        default: chirality = .unknown
        }

        return TrackedHand(
            id: "hand-\(index)-\(chirality.rawValue)",
            chirality: chirality,
            joints: joints,
            palm: {
                if let w = pt(.wrist), let i = pt(.indexMCP) {
                    return CGPoint(x: (w.x + i.x) / 2, y: (w.y + i.y) / 2)
                }
                return pt(.wrist)
            }(),
            wrist: pt(.wrist),
            indexTip: pt(.indexTip),
            thumbTip: pt(.thumbTip)
        )
    }
}
