import Foundation
import ARKit
import Vision
import Combine

final class VisionManager {
    let queue = DispatchQueue(label: "jarvis.vision", qos: .userInitiated)
    let handPosePublisher = PassthroughSubject<[VNHumanHandPoseObservation], Never>()
    let classificationPublisher = PassthroughSubject<ClassificationResult, Never>()
    let ocrPublisher = PassthroughSubject<[OCRLine], Never>()

    private(set) var isReady = false
    var scanEnabled = false

    private let handRequest: VNDetectHumanHandPoseRequest = {
        let r = VNDetectHumanHandPoseRequest()
        r.maximumHandCount = 2
        return r
    }()

    private let classifyRequest = VNClassifyImageRequest()
    private let textRequest: VNRecognizeTextRequest = {
        let r = VNRecognizeTextRequest()
        r.recognitionLevel = .accurate
        r.usesLanguageCorrection = true
        return r
    }()

    private var frameIndex = 0
    private let handEvery = 2
    private let classifyEvery = 30
    private var lastClassify: TimeInterval = 0

    func prepare() -> Bool {
        isReady = true
        return true
    }

    func handle(frame: ARFrame) {
        frameIndex += 1
        let buffer = frame.capturedImage
        let orientation = CGImagePropertyOrientation.right
        if frameIndex % handEvery == 0 {
            runHands(buffer: buffer, orientation: orientation)
        }
        if scanEnabled {
            let now = CACurrentMediaTime()
            if now - lastClassify > 0.6 {
                lastClassify = now
                runClassifyAndOCR(buffer: buffer, orientation: orientation)
            }
        }
    }

    private func runHands(buffer: CVPixelBuffer, orientation: CGImagePropertyOrientation) {
        let handler = VNImageRequestHandler(cvPixelBuffer: buffer, orientation: orientation, options: [:])
        do {
            try handler.perform([handRequest])
            let results = (handRequest.results ?? []).prefix(2)
            handPosePublisher.send(Array(results))
        } catch {
            handPosePublisher.send([])
        }
    }

    private func runClassifyAndOCR(buffer: CVPixelBuffer, orientation: CGImagePropertyOrientation) {
        let handler = VNImageRequestHandler(cvPixelBuffer: buffer, orientation: orientation, options: [:])
        do {
            try handler.perform([classifyRequest, textRequest])
            if let observations = classifyRequest.results?.prefix(5) {
                let top = observations.compactMap { obs -> (String, Float)? in
                    guard obs.confidence > 0.15 else { return nil }
                    return (obs.identifier, obs.confidence)
                }
                if let best = top.first {
                    classificationPublisher.send(
                        ClassificationResult(label: best.0, confidence: best.1, alternatives: top.map { $0.0 })
                    )
                }
            }
            let lines: [OCRLine] = (textRequest.results ?? []).compactMap { obs in
                guard let candidate = obs.topCandidates(1).first, candidate.confidence > 0.4 else { return nil }
                return OCRLine(text: candidate.string, confidence: candidate.confidence)
            }
            if !lines.isEmpty {
                ocrPublisher.send(lines)
            }
        } catch {
            // keep last known labels
        }
    }
}

struct ClassificationResult {
    var label: String
    var confidence: Float
    var alternatives: [String]
}

struct OCRLine {
    var text: String
    var confidence: Float
}
