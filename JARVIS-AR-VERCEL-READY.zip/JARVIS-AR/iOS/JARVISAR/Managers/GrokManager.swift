import Foundation

@MainActor
final class GrokManager: ObservableObject {
    @Published var status: ServiceStatus = .unknown
    @Published var conversationId = UUID().uuidString

    private var settings: SettingsManager { SettingsManager.shared }

    func ping() async -> Bool {
        guard let url = URL(string: settings.backendBaseURL + "/v1/health") else {
            status = .offline
            return false
        }
        var req = URLRequest(url: url)
        req.timeoutInterval = 4
        do {
            let (_, response) = try await URLSession.shared.data(for: req)
            let ok = (response as? HTTPURLResponse)?.statusCode == 200
            status = ok ? .connected : .offline
            return ok
        } catch {
            status = .offline
            return false
        }
    }

    func send(_ turn: JarvisTurnRequest) async throws -> JarvisTurnResponse {
        guard let url = URL(string: settings.backendBaseURL + "/v1/jarvis/turn") else {
            throw JarvisError.badConfig
        }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 45
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("Bearer \(settings.appAPIToken)", forHTTPHeaderField: "Authorization")
        req.httpBody = try JSONEncoder().encode(turn)
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse else { throw JarvisError.network }
        guard (200..<300).contains(http.statusCode) else {
            status = .offline
            throw JarvisError.http(http.statusCode)
        }
        status = .connected
        let decoded = try JSONDecoder().decode(JarvisTurnResponse.self, from: data)
        if let id = decoded.conversationId { conversationId = id }
        return decoded
    }
}

enum ServiceStatus: String {
    case unknown = "…"
    case connected = "CONNECTED"
    case offline = "OFFLINE"
}

enum JarvisError: Error {
    case badConfig
    case network
    case http(Int)
}
