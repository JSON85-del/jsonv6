import Foundation
import Combine
import simd

@MainActor
final class CommandManager: ObservableObject {
    let spokenReply = PassthroughSubject<String, Never>()
    private weak var state: AppState?

    func bind(state: AppState) {
        self.state = state
    }

    func execute(_ command: JarvisCommand) {
        guard let state else { return }
        guard state.security.allows(command) else {
            spokenReply.send("That action is not permitted.")
            return
        }
        switch command.intent {
        case .scanObject:
            state.setMode(.scan)
            state.vision.scanEnabled = true
            spokenReply.send("Scanning.")
        case .selectObject:
            spokenReply.send("Target selected.")
        case .moveObject:
            state.interaction.nudgeSelected(direction: command.direction ?? "toward_user",
                                            magnitude: Float(command.magnitude ?? 0.2))
        case .rotateObject:
            state.interaction.rotateSelected(radians: Float(command.magnitude ?? 0.4))
        case .scaleObject:
            let s = Float(command.magnitude ?? 1.15)
            state.interaction.scaleSelected(s)
        case .openPanel:
            state.hud.radialOpen = true
        case .closePanel:
            state.hud.radialOpen = false
            state.hud.dismissInfo()
        case .search:
            let q = command.query ?? state.objects.primaryLabel ?? ""
            spokenReply.send(q.isEmpty ? "Nothing to search yet." : "Searching for \(q).")
        case .readText:
            let text = state.objects.ocrLines.joined(separator: ", ")
            spokenReply.send(text.isEmpty ? "I cannot read any text from this view." : text)
        case .showInformation:
            state.hud.showInfoFrom(objects: state.objects, products: state.products)
            spokenReply.send(state.objects.spokenSummary())
        case .changeMode:
            if let raw = command.mode, let mode = JarvisMode(rawValue: raw) {
                state.setMode(mode)
            }
        case .startNavigation:
            state.setMode(.navigation)
            spokenReply.send("Navigation mode is limited to on-device AR waypoints this session.")
        case .createARObject:
            state.interaction.spawnHologram(type: command.objectType ?? "cube")
            spokenReply.send("Placing a holographic marker.")
        case .remember:
            state.spatial.rememberSelected(note: command.query ?? state.objects.primaryLabel)
            spokenReply.send("I'll keep that anchored for this session.")
        }
    }
}
