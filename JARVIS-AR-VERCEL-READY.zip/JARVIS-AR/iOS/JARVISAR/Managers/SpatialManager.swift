import Foundation
import RealityKit
import simd

struct SpatialMemoryItem: Identifiable {
    var id = UUID()
    var note: String?
    var worldPosition: SIMD3<Float>
    var createdAt = Date()
}

@MainActor
final class SpatialManager: ObservableObject {
    @Published var items: [SpatialMemoryItem] = []
    private weak var ar: ARManager?

    func bind(ar: ARManager) {
        self.ar = ar
    }

    func rememberSelected(note: String?) {
        guard let ar else { return }
        let center = CGPoint(x: ar.viewBounds.width / 2, y: ar.viewBounds.height / 2)
        let world = ar.raycast(from: center) ?? SIMD3<Float>(0, 0, -0.7)
        let item = SpatialMemoryItem(note: note, worldPosition: world)
        items.append(item)
        let panel = HologramFactory.note(text: note ?? "Pinned")
        ar.addEntity(panel, at: world)
    }

    /// Session-only. Permanent world maps require an explicit ARWorldMap save, not enabled by default.
    func clearSession() {
        items.removeAll()
    }
}
