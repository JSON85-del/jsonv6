import Foundation
import RealityKit
import simd
import UIKit

@MainActor
final class InteractionController {
    private weak var ar: ARManager?
    private weak var spatial: SpatialManager?
    private weak var hud: HUDManager?
    private var haptics: HapticsManager?
    private var sound: SoundManager?
    private var products: ProductManager?
    private var selected: Entity?
    private var lastOpenPalm: TimeInterval = 0

    func bind(ar: ARManager, spatial: SpatialManager, hud: HUDManager, haptics: HapticsManager, sound: SoundManager, products: ProductManager) {
        self.ar = ar
        self.spatial = spatial
        self.hud = hud
        self.haptics = haptics
        self.sound = sound
        self.products = products
    }

    func handle(event: GestureEvent, state: AppState?) {
        hud?.cursor = event.screenPoint
        switch event.kind {
        case .point:
            if let p = event.screenPoint {
                if let entity = ar?.hitTestEntities(screen: p) {
                    hud?.hoverLabel = entity.name
                    haptics?.hover()
                } else {
                    hud?.hoverLabel = hitHUDLabel(at: p)
                }
            }
        case .pinch:
            if let p = event.screenPoint {
                if let label = hitHUDLabel(at: p) {
                    activateHUD(label, state: state)
                    haptics?.select()
                    sound?.play(.select)
                    return
                }
                if let entity = ar?.hitTestEntities(screen: p) {
                    selected = entity
                    hud?.hoverLabel = "SELECTED"
                    haptics?.select()
                    sound?.play(.lock)
                }
            }
        case .doublePinch:
            haptics?.confirm()
            sound?.play(.confirm)
            state?.commands.execute(JarvisCommand(intent: .showInformation, target: nil, direction: nil, magnitude: nil, mode: nil, query: nil, objectType: nil))
        case .grab, .move:
            if let selected, let p = event.screenPoint, let world = ar?.raycast(from: p) {
                selected.position = world
            }
        case .release:
            hud?.hoverLabel = nil
        case .twoHandScale:
            if let selected, let s = event.scale {
                let f = Float(s)
                selected.scale *= SIMD3<Float>(repeating: max(0.4, min(2.5, f)))
            }
        case .twoHandRotate:
            if let selected, let r = event.rotation {
                selected.orientation *= simd_quatf(angle: Float(r), axis: SIMD3<Float>(0, 1, 0))
            }
        case .openPalm:
            let now = CACurrentMediaTime()
            if now - lastOpenPalm > 0.8 {
                hud?.radialOpen.toggle()
                haptics?.confirm()
                lastOpenPalm = now
            }
        case .swipe:
            if event.swipeDirection == "down" {
                hud?.dismissInfo()
                hud?.radialOpen = false
            }
        }
    }

    func spawnHologram(type: String) {
        guard let ar else { return }
        let center = CGPoint(x: ar.viewBounds.width / 2, y: ar.viewBounds.height * 0.62)
        let world = ar.raycast(from: center) ?? SIMD3<Float>(0, -0.05, -0.55)
        let entity = type == "note" ? HologramFactory.note(text: "Note") : HologramFactory.cube()
        ar.addEntity(entity, at: world)
        selected = entity
    }

    func nudgeSelected(direction: String, magnitude: Float) {
        guard let selected, let ar, let frame = ar.latestFrame else { return }
        let cam = frame.camera.transform.translation
        var pos = selected.position(relativeTo: nil)
        switch direction {
        case "toward_user":
            let dir = simd_normalize(cam - pos)
            pos += dir * magnitude
        case "away":
            let dir = simd_normalize(pos - cam)
            pos += dir * magnitude
        case "up": pos.y += magnitude
        case "down": pos.y -= magnitude
        default: pos.z += magnitude * 0.1
        }
        selected.setPosition(pos, relativeTo: nil)
    }

    func rotateSelected(radians: Float) {
        selected?.orientation *= simd_quatf(angle: radians, axis: SIMD3<Float>(0, 1, 0))
    }

    func scaleSelected(_ factor: Float) {
        selected?.scale *= SIMD3<Float>(repeating: factor)
    }

    private func hitHUDLabel(at point: CGPoint) -> String? {
        guard hud?.radialOpen == true else { return nil }
        // Approximate radial slots in normalized overlay space; refined in HUD view via preference keys if needed.
        return hud?.hoverLabel
    }

    private func activateHUD(_ label: String, state: AppState?) {
        switch label.uppercased() {
        case "SCAN": state?.setMode(.scan); state?.commands.execute(JarvisCommand(intent: .scanObject, target: nil, direction: nil, magnitude: nil, mode: nil, query: nil, objectType: nil))
        case "SEARCH": state?.commands.execute(JarvisCommand(intent: .search, target: nil, direction: nil, magnitude: nil, mode: nil, query: nil, objectType: nil))
        case "MAP": state?.setMode(.navigation)
        case "SYSTEM": state?.setMode(.system)
        case "MEMORY": state?.commands.execute(JarvisCommand(intent: .remember, target: nil, direction: nil, magnitude: nil, mode: nil, query: nil, objectType: nil))
        case "DETAILS", "STOCK": state?.commands.execute(JarvisCommand(intent: .showInformation, target: nil, direction: nil, magnitude: nil, mode: nil, query: nil, objectType: nil))
        default: break
        }
    }
}
