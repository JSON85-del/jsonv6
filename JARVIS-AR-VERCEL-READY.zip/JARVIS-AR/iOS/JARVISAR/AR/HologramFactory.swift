import RealityKit
import UIKit

enum HologramFactory {
    static func cube() -> ModelEntity {
        let mesh = MeshResource.generateBox(size: 0.12, cornerRadius: 0.004)
        var material = SimpleMaterial()
        material.color = .init(tint: UIColor(red: 0.15, green: 0.85, blue: 1.0, alpha: 0.35), texture: nil)
        material.metallic = 0.2
        material.roughness = 0.15
        let entity = ModelEntity(mesh: mesh, materials: [material])
        entity.generateCollisionShapes(recursive: true)
        entity.name = "holo-cube"
        return entity
    }

    static func note(text: String) -> ModelEntity {
        let mesh = MeshResource.generatePlane(width: 0.22, height: 0.08, cornerRadius: 0.008)
        var material = SimpleMaterial()
        material.color = .init(tint: UIColor(red: 0.05, green: 0.18, blue: 0.28, alpha: 0.72), texture: nil)
        let entity = ModelEntity(mesh: mesh, materials: [material])
        entity.name = "holo-note"
        entity.generateCollisionShapes(recursive: true)
        return entity
    }
}
