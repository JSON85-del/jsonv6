import Foundation
import Combine
import SwiftUI

@MainActor
final class AppState: ObservableObject {
    @Published var phase: LaunchPhase = .initializing
    @Published var mode: JarvisMode = .defaultMode
    @Published var showSettings = false
    @Published var showPrivacy = false
    @Published var selectedEntityID: UUID?
    @Published var lastUserTranscript: String = ""
    @Published var lastAssistantLine: String = ""
    @Published var isListening = false
    @Published var isSpeaking = false
    @Published var isProcessingAI = false

    let ar = ARManager()
    let vision = VisionManager()
    let hands = HandTrackingManager()
    let gestures = GestureManager()
    let voice = VoiceManager()
    let grok = GrokManager()
    let commands = CommandManager()
    let spatial = SpatialManager()
    let hud = HUDManager()
    let objects = ObjectRecognitionManager()
    let products = ProductManager()
    let mhm = MHMManager()
    let settings = SettingsManager.shared
    let security = SecurityManager()
    let haptics = HapticsManager()
    let sound = SoundManager()
    let interaction = InteractionController()

    private var bag = Set<AnyCancellable>()

    init() {
        wire()
    }

    func wire() {
        ar.framePublisher
            .receive(on: vision.queue)
            .sink { [weak self] frame in
                self?.vision.handle(frame: frame)
            }
            .store(in: &bag)

        vision.handPosePublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] observations in
                guard let self else { return }
                self.hands.update(observations: observations, viewSize: self.ar.viewBounds, frame: self.ar.latestFrame)
                self.gestures.update(hands: self.hands.hands, settings: self.settings)
            }
            .store(in: &bag)

        vision.classificationPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] result in
                self?.objects.applyClassification(result)
            }
            .store(in: &bag)

        vision.ocrPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] texts in
                self?.objects.applyOCR(texts)
            }
            .store(in: &bag)

        gestures.events
            .receive(on: DispatchQueue.main)
            .sink { [weak self] event in
                self?.interaction.handle(event: event, state: self)
            }
            .store(in: &bag)

        voice.transcriptPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] text in
                Task { await self?.handleVoice(text) }
            }
            .store(in: &bag)

        commands.spokenReply
            .receive(on: DispatchQueue.main)
            .sink { [weak self] line in
                self?.lastAssistantLine = line
                self?.voice.speak(line)
            }
            .store(in: &bag)
    }

    func bootstrap() async {
        phase = .initializing
        hud.resetBootLog()
        sound.play(.startup)

        await hud.mark("CAMERA", success: await ar.requestCamera())
        await hud.mark("AR ENGINE", success: await ar.start())
        await hud.mark("VISION", success: vision.prepare())
        await hud.mark("HAND TRACKING", success: hands.prepare())
        await hud.mark("VOICE", success: await voice.prepare())
        await hud.mark("GROK", success: await grok.ping())

        spatial.bind(ar: ar)
        interaction.bind(ar: ar, spatial: spatial, hud: hud, haptics: haptics, sound: sound, products: products)
        commands.bind(state: self)
        products.configure(settings: settings)
        mhm.configure(settings: settings)

        let allCritical = ar.isRunning && vision.isReady
        phase = allCritical ? .ready : .degraded
        if phase == .ready {
            let greeting = TimeOfDay.greeting()
            lastAssistantLine = "\(greeting) How can I assist you?"
            voice.speak(lastAssistantLine)
        }
    }

    func handleVoice(_ raw: String) async {
        lastUserTranscript = raw
        let filtered = voice.applyWakeFilter(raw, alwaysListen: settings.alwaysListenAfterTap)
        guard let query = filtered else { return }
        isProcessingAI = true
        hud.aiState = .processing
        defer {
            isProcessingAI = false
            hud.aiState = .idle
        }
        let context = JarvisTurnRequest(
            userQuery: query,
            detectedObject: objects.primaryLabel,
            ocrText: objects.ocrLines,
            context: "AR_CAMERA",
            mode: mode.rawValue,
            availableActions: JarvisCommand.Intent.allCases.map(\.rawValue),
            conversationId: grok.conversationId
        )
        do {
            let turn = try await grok.send(context)
            if let command = turn.command {
                commands.execute(command)
            }
            if let speech = turn.speech, !speech.isEmpty {
                lastAssistantLine = speech
                voice.speak(speech)
            }
        } catch {
            hud.grokStatus = .offline
            lastAssistantLine = "AI connection unavailable. Local systems are still running."
            voice.speak(lastAssistantLine)
        }
    }

    func setMode(_ next: JarvisMode) {
        mode = next
        vision.scanEnabled = (next == .scan || next == .product || next == .mhm)
        hud.modeLabel = next.title
        sound.play(.confirm)
    }
}

enum LaunchPhase {
    case initializing
    case ready
    case degraded
}

enum TimeOfDay {
    static func greeting() -> String {
        let hour = Calendar.current.component(.hour, from: Date())
        switch hour {
        case 5..<12: return "Good morning."
        case 12..<17: return "Good afternoon."
        case 17..<22: return "Good evening."
        default: return "Hello."
        }
    }
}
