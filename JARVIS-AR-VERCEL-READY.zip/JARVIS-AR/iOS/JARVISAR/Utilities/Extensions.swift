import Foundation
import SwiftUI

extension View {
    func jarvisGlass() -> some View {
        self
            .background(.ultraThinMaterial.opacity(0.45))
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(HUDTheme.cyan.opacity(0.4), lineWidth: 0.7)
            )
    }
}
